package com.example.addon.modules;

import com.example.addon.AddonTemplate;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.DoubleSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.math.Vec3d;

/**
 * При полёте на элитрах, в момент касания земли, подбрасывает игрока вверх
 * и сразу заново раскрывает элитры, так что полёт не прерывается.
 */
public class ElytraJump extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> minImpact = sgGeneral.add(new DoubleSetting.Builder()
        .name("min-impact-speed")
        .description("Минимальная вертикальная скорость падения (блоков/тик), с которой срабатывает отскок.")
        .defaultValue(0.3)
        .range(0.0, 3.0)
        .sliderRange(0.0, 2.0)
        .build()
    );

    private final Setting<Double> bounceMultiplier = sgGeneral.add(new DoubleSetting.Builder()
        .name("bounce-multiplier")
        .description("Какую долю скорости падения превратить в скорость прыжка вверх.")
        .defaultValue(0.7)
        .range(0.0, 3.0)
        .sliderRange(0.0, 2.0)
        .build()
    );

    private final Setting<Double> minBounce = sgGeneral.add(new DoubleSetting.Builder()
        .name("min-bounce")
        .description("Минимальная скорость отскока вверх (обычный прыжок = 0.42).")
        .defaultValue(0.5)
        .range(0.0, 3.0)
        .sliderRange(0.0, 2.0)
        .build()
    );

    private final Setting<Double> maxBounce = sgGeneral.add(new DoubleSetting.Builder()
        .name("max-bounce")
        .description("Максимальная скорость отскока вверх.")
        .defaultValue(1.2)
        .range(0.1, 5.0)
        .sliderRange(0.1, 3.0)
        .build()
    );

    private final Setting<Double> horizontalKeep = sgGeneral.add(new DoubleSetting.Builder()
        .name("horizontal-keep")
        .description("Какую часть горизонтальной скорости сохранить при отскоке.")
        .defaultValue(0.9)
        .range(0.0, 1.5)
        .sliderRange(0.0, 1.2)
        .build()
    );

    private final Setting<Integer> cooldown = sgGeneral.add(new IntSetting.Builder()
        .name("cooldown")
        .description("Задержка между отскоками (в тиках).")
        .defaultValue(5)
        .range(0, 40)
        .sliderRange(0, 20)
        .build()
    );

    private final Setting<Boolean> sneakCancels = sgGeneral.add(new BoolSetting.Builder()
        .name("sneak-cancels")
        .description("Если зажат Shift — отскока нет (чтобы можно было нормально приземлиться).")
        .defaultValue(true)
        .build()
    );

    // Состояние на начало тика (до движения)
    private boolean preGliding;
    private boolean preOnGround;
    private Vec3d preVelocity = Vec3d.ZERO;

    private int cooldownLeft;
    private int reglideTicks;

    public ElytraJump() {
        super(AddonTemplate.CATEGORY, "elytra-jump", "Отскакиваешь от земли при касании во время полёта на элитрах и взлетаешь снова.");
    }

    @Override
    public void onActivate() {
        preGliding = false;
        preOnGround = false;
        preVelocity = Vec3d.ZERO;
        cooldownLeft = 0;
        reglideTicks = 0;
    }

    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (mc.player == null) return;

        preGliding = mc.player.isGliding();
        preOnGround = mc.player.isOnGround();
        preVelocity = mc.player.getVelocity();
    }

    @EventHandler
    private void onPostTick(TickEvent.Post event) {
        if (mc.player == null || mc.world == null) return;

        if (cooldownLeft > 0) cooldownLeft--;

        // Снова раскрываем элитры после отскока
        if (reglideTicks > 0) {
            reglideTicks--;

            if (!mc.player.isOnGround() && !mc.player.isGliding() && hasElytra()) {
                mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                mc.player.startGliding();
                reglideTicks = 0;
            }
            return;
        }

        // Касание земли: в начале тика летели в воздухе, после движения — на земле
        if (!(preGliding && !preOnGround && mc.player.isOnGround())) return;
        if (cooldownLeft > 0) return;
        if (sneakCancels.get() && mc.player.isSneaking()) return;
        if (!hasElytra()) return;

        double impact = -preVelocity.y;
        if (impact < minImpact.get()) return;

        double up = Math.min(Math.max(impact * bounceMultiplier.get(), minBounce.get()), maxBounce.get());
        double keep = horizontalKeep.get();

        mc.player.setVelocity(preVelocity.x * keep, up, preVelocity.z * keep);
        mc.player.setOnGround(false);

        cooldownLeft = cooldown.get();
        reglideTicks = 3;
    }

    private boolean hasElytra() {
        ItemStack chest = mc.player.getEquippedStack(EquipmentSlot.CHEST);
        return chest.isOf(Items.ELYTRA) && chest.getMaxDamage() - chest.getDamage() > 1;
    }
}
